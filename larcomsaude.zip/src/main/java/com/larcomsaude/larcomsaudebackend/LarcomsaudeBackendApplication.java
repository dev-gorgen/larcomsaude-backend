package com.larcomsaude.larcomsaudebackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LarcomsaudeBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(LarcomsaudeBackendApplication.class, args);
	}

}
